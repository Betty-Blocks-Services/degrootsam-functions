import { default as tryCatch_1_1 } from './functions/try-catch/1.1';
import { default as tryCatch_1_0 } from './functions/try-catch/1.0';

const fn = {
  "tryCatch 1.1": tryCatch_1_1,
  "tryCatch 1.0": tryCatch_1_0,
};

export default fn;
